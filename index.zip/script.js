(() => {
  'use strict';

  const SAVE_KEY = 'studyForge.phase1.v1';
  const TODAY_KEY = () => new Date().toISOString().slice(0, 10);

  const FALLBACK_QUESTIONS = [
    {id:'fallback-1',question:'筋収縮に必要なカルシウムイオンは主にどこから放出されるか。',choices:['筋小胞体','核','ゴルジ装置','細胞外のみ'],correct:0,explanation:'骨格筋では活動電位により筋小胞体からCa²⁺が放出され、収縮が始まります。',subject:'運動生理',year:'基礎',difficulty:1},
    {id:'fallback-2',question:'膝関節伸展の主働筋群はどれか。',choices:['大腿四頭筋','ハムストリングス','下腿三頭筋','腸腰筋'],correct:0,explanation:'大腿四頭筋は膝伸展の主働筋群です。',subject:'機能解剖',year:'基礎',difficulty:1},
    {id:'fallback-3',question:'力積と等しいものはどれか。',choices:['運動量の変化量','加速度の二乗','位置エネルギー','密度'],correct:0,explanation:'力積は力×時間で、運動量の変化量に等しいです。',subject:'バイオメカニクス',year:'基礎',difficulty:2}
  ];

  const defaultState = () => ({
    version: 1,
    player: {
      level: 1, exp: 0, hp: 100, maxHp: 100, atk: 12, def: 5,
      critical: 0.08, speed: 10, forgePower: 1
    },
    currency: { gold: 0, forgeEnergy: 0 },
    study: {
      combo: 0, bestCombo: 0, totalAnswered: 0, totalCorrect: 0,
      reviewIds: [], history: {}, mode: 'normal', lastQuestionId: null,
      filters: { subject: 'all', difficulty: 'all' }
    },
    battle: { wins: 0, enemyIndex: 0, playerHp: 100 },
    today: { date: TODAY_KEY(), answered: 0, correct: 0 },
    settings: { sound: false }
  });

  let state = loadState();
  let questions = [...FALLBACK_QUESTIONS];
  let currentQuestion = null;
  let currentBattleQuestion = null;
  let studyAnswered = false;
  let battleAnswered = false;
  let currentEnemy = null;
  let guardActive = false;

  const $ = (id) => document.getElementById(id);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));

  const ENEMIES = [
    {name:'Ashfang Wolf', tier:'NORMAL', hp:76, atk:10, exp:24, gold:16},
    {name:'Ironhide Boar', tier:'NORMAL', hp:95, atk:12, exp:28, gold:19},
    {name:'Ember Wraith', tier:'ELITE', hp:122, atk:15, exp:36, gold:25},
    {name:'Forge Sentinel', tier:'MINI BOSS', hp:165, atk:18, exp:52, gold:38}
  ];

  function loadState() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return defaultState();
      const parsed = JSON.parse(raw);
      const base = defaultState();
      const merged = {
        ...base, ...parsed,
        player: {...base.player, ...(parsed.player || {})},
        currency: {...base.currency, ...(parsed.currency || {})},
        study: {...base.study, ...(parsed.study || {})},
        battle: {...base.battle, ...(parsed.battle || {})},
        today: {...base.today, ...(parsed.today || {})},
        settings: {...base.settings, ...(parsed.settings || {})}
      };
      if (merged.today.date !== TODAY_KEY()) merged.today = {date:TODAY_KEY(), answered:0, correct:0};
      merged.battle.playerHp = Math.min(merged.battle.playerHp || merged.player.maxHp, merged.player.maxHp);
      return merged;
    } catch (err) {
      console.warn('Save load failed:', err);
      return defaultState();
    }
  }

  function saveState() {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(state)); }
    catch (err) { console.warn('Save failed:', err); }
  }

  function validQuestion(q) {
    return q && typeof q.id === 'string' && typeof q.question === 'string' &&
      Array.isArray(q.choices) && q.choices.length >= 2 && Number.isInteger(q.correct) &&
      q.correct >= 0 && q.correct < q.choices.length;
  }

  async function loadQuestions() {
    try {
      if (Array.isArray(window.STUDY_FORGE_QUESTIONS) && window.STUDY_FORGE_QUESTIONS.length >= 3) {
        questions = window.STUDY_FORGE_QUESTIONS.filter(validQuestion);
        return;
      }
      const response = await fetch('data/questions.json', {cache:'no-store'});
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (Array.isArray(data) && data.length >= 3) questions = data.filter(validQuestion);
    } catch (err) {
      console.info('Using built-in fallback question set.', err);
    }
  }

  function normalizeFilters() {
    if (!state.study.filters || typeof state.study.filters !== 'object') {
      state.study.filters = {subject:'all', difficulty:'all'};
    }
    state.study.filters.subject ||= 'all';
    state.study.filters.difficulty ||= 'all';
  }

  function buildQuestionFilters() {
    normalizeFilters();
    const subjects = [...new Set(questions.map(q => q.subject || 'GENERAL'))].sort((a,b) => a.localeCompare(b,'ja'));
    const select = $('subjectFilter');
    select.innerHTML = '<option value="all">ALL SUBJECTS</option>' +
      subjects.map(subject => `<option value="${escapeHtml(subject)}">${escapeHtml(subject)}</option>`).join('');
    if (subjects.includes(state.study.filters.subject)) select.value = state.study.filters.subject;
    else { state.study.filters.subject = 'all'; select.value = 'all'; }
    $('difficultyFilter').value = ['1','2','3'].includes(String(state.study.filters.difficulty)) ? String(state.study.filters.difficulty) : 'all';
  }

  function expToNext(level = state.player.level) {
    return Math.round(100 * Math.pow(1.18, level - 1));
  }

  function comboMultiplier() {
    const combo = state.study.combo;
    if (combo >= 20) return 1.65;
    if (combo >= 10) return 1.4;
    if (combo >= 5) return 1.22;
    if (combo >= 3) return 1.1;
    return 1;
  }

  function titleForLevel(level) {
    if (level >= 20) return 'Master Forger';
    if (level >= 12) return 'Arcane Forger';
    if (level >= 7) return 'Steel Forger';
    if (level >= 3) return 'Apprentice Forger';
    return 'Rookie Forger';
  }

  function rankForLevel(level) {
    if (level >= 20) return 'V';
    if (level >= 12) return 'IV';
    if (level >= 7) return 'III';
    if (level >= 3) return 'II';
    return 'I';
  }

  function addRewards({exp=0,gold=0,energy=0}, showToast = true) {
    state.player.exp += exp;
    state.currency.gold += gold;
    state.currency.forgeEnergy += energy;
    let levelsGained = 0;
    while (state.player.exp >= expToNext()) {
      state.player.exp -= expToNext();
      state.player.level += 1;
      state.player.maxHp += 12;
      state.player.hp = state.player.maxHp;
      state.battle.playerHp = state.player.maxHp;
      state.player.atk += 3;
      state.player.def += 2;
      state.player.critical = Math.min(.25, state.player.critical + .005);
      state.player.speed += 1;
      levelsGained++;
    }
    if (showToast && (exp || gold || energy)) toast(`<b>REWARD</b> +${exp} EXP / +${gold} G / +${energy} FE`);
    if (levelsGained) showLevelUp(levelsGained);
    saveState();
    renderAll();
  }

  function showLevelUp(levelsGained) {
    $('levelBurst').textContent = state.player.level;
    $('levelUpText').textContent = `LEVEL ${state.player.level} — HP +${12*levelsGained} / ATK +${3*levelsGained} / DEF +${2*levelsGained}`;
    $('levelUpModal').classList.remove('hidden');
  }

  function toast(html) {
    const item = document.createElement('div');
    item.className = 'toast';
    item.innerHTML = html;
    $('toastStack').appendChild(item);
    setTimeout(() => item.remove(), 2800);
  }

  function navigate(screen) {
    $$('.screen').forEach(el => el.classList.toggle('active', el.dataset.screen === screen));
    $$('.nav-btn').forEach(el => el.classList.toggle('active', el.dataset.nav === screen));
    if (screen === 'study' && !currentQuestion) nextStudyQuestion();
    if (screen === 'battle') ensureEnemy();
    window.scrollTo({top:0, behavior:'smooth'});
    renderAll();
  }

  function renderAll() {
    $('goldValue').textContent = state.currency.gold.toLocaleString();
    $('forgeEnergyValue').textContent = state.currency.forgeEnergy.toLocaleString();
    $('homeLevel').textContent = state.player.level;
    $('playerTitle').textContent = titleForLevel(state.player.level);
    $('rankEmblem').textContent = rankForLevel(state.player.level);
    const need = expToNext();
    $('expText').textContent = `${state.player.exp} / ${need}`;
    $('expBar').style.width = `${Math.min(100, state.player.exp / need * 100)}%`;
    $('statHp').textContent = state.player.maxHp;
    $('statAtk').textContent = state.player.atk;
    $('statDef').textContent = state.player.def;
    $('statCrit').textContent = `${Math.round(state.player.critical * 100)}%`;
    $('todayAnswered').textContent = state.today.answered;
    $('todayCorrect').textContent = state.today.correct;
    $('todayAccuracy').textContent = state.today.answered ? `${Math.round(state.today.correct / state.today.answered * 100)}%` : '—';
    $('bestCombo').textContent = state.study.bestCombo;
    $('reviewCount').textContent = state.study.reviewIds.length;
    $('questionBankCount').textContent = questions.length.toLocaleString();
    $('questionSubjectCount').textContent = `${new Set(questions.map(q => q.subject || 'GENERAL')).size} SUBJECTS`;
    $('studyCombo').textContent = state.study.combo;
    updatePoolCount();
    $('battleWins').textContent = state.battle.wins;
    $('battleAtk').textContent = state.player.atk;
    $('battleEnergy').textContent = state.currency.forgeEnergy;

    if (currentQuestion && !studyAnswered) renderRewardPreview(currentQuestion);
    renderBattleBars();
  }

  function renderRewardPreview(question) {
    const mult = comboMultiplier();
    const baseExp = 10 + (question.difficulty || 1) * 3;
    const baseGold = 6 + (question.difficulty || 1) * 2;
    const baseEnergy = 1 + Math.ceil((question.difficulty || 1) / 2);
    $('previewExp').textContent = `+${Math.round(baseExp * mult)}`;
    $('previewGold').textContent = `+${Math.round(baseGold * mult)}`;
    $('previewEnergy').textContent = `+${baseEnergy}`;
    $('comboMultiplier').textContent = `COMBO ×${mult.toFixed(2)}`;
  }

  function questionPool(mode = state.study.mode) {
    normalizeFilters();
    let pool = questions;
    if (mode === 'review') {
      const set = new Set(state.study.reviewIds);
      const reviewPool = questions.filter(q => set.has(q.id));
      pool = reviewPool.length ? reviewPool : questions;
    }
    const subject = state.study.filters.subject;
    const difficulty = state.study.filters.difficulty;
    const filtered = pool.filter(q =>
      (subject === 'all' || (q.subject || 'GENERAL') === subject) &&
      (difficulty === 'all' || String(q.difficulty || 1) === String(difficulty))
    );
    return filtered.length ? filtered : pool;
  }

  function updatePoolCount() {
    if (!$('poolCount')) return;
    const pool = questionPool(state.study.mode);
    $('poolCount').textContent = `POOL ${pool.length.toLocaleString()} / BANK ${questions.length.toLocaleString()}`;
  }

  function setQuestionFilter(kind, value) {
    normalizeFilters();
    state.study.filters[kind] = value;
    saveState();
    updatePoolCount();
    nextStudyQuestion();
  }

  function pickQuestion(mode = state.study.mode, excludeId = null) {
    const pool = questionPool(mode);
    const candidates = pool.length > 1 ? pool.filter(q => q.id !== excludeId) : pool;
    return candidates[Math.floor(Math.random() * candidates.length)] || FALLBACK_QUESTIONS[0];
  }

  function nextStudyQuestion() {
    studyAnswered = false;
    currentQuestion = pickQuestion(state.study.mode, state.study.lastQuestionId);
    state.study.lastQuestionId = currentQuestion.id;
    $('questionSubject').textContent = currentQuestion.subject || 'GENERAL';
    $('questionDifficulty').textContent = ['EASY','NORMAL','HARD'][Math.max(0, Math.min(2, (currentQuestion.difficulty || 1)-1))];
    $('questionYear').textContent = currentQuestion.year || '—';
    $('questionCounter').textContent = state.study.mode === 'review' ? 'REVIEW QUESTION' : 'TRAINING QUESTION';
    $('questionText').textContent = currentQuestion.question;
    $('answerFeedback').className = 'answer-feedback';
    $('answerFeedback').innerHTML = '';
    $('nextQuestionBtn').classList.add('hidden');
    renderChoices($('choiceGrid'), currentQuestion, (index, btns) => answerStudy(index, btns));
    renderRewardPreview(currentQuestion);
  }

  function renderChoices(container, question, onPick) {
    container.innerHTML = '';
    question.choices.forEach((choice, index) => {
      const btn = document.createElement('button');
      btn.className = 'choice-btn';
      btn.innerHTML = `<span class="choice-key">${String.fromCharCode(65+index)}</span><span>${escapeHtml(choice)}</span>`;
      btn.addEventListener('click', () => onPick(index, Array.from(container.querySelectorAll('.choice-btn'))));
      container.appendChild(btn);
    });
  }

  function answerStudy(index, buttons) {
    if (studyAnswered) return;
    studyAnswered = true;
    const q = currentQuestion;
    const correct = index === q.correct;
    buttons.forEach((btn, i) => {
      btn.disabled = true;
      if (i === q.correct) btn.classList.add('correct');
      if (i === index && !correct) btn.classList.add('wrong');
    });

    state.study.totalAnswered++;
    state.today.answered++;
    state.study.history[q.id] = {answered:(state.study.history[q.id]?.answered || 0)+1, correct:(state.study.history[q.id]?.correct || 0)+(correct?1:0), lastCorrect:correct};

    if (correct) {
      state.study.totalCorrect++;
      state.today.correct++;
      state.study.combo++;
      state.study.bestCombo = Math.max(state.study.bestCombo, state.study.combo);
      state.study.reviewIds = state.study.reviewIds.filter(id => id !== q.id);
      const mult = comboMultiplier();
      const exp = Math.round((10 + (q.difficulty||1)*3) * mult);
      const gold = Math.round((6 + (q.difficulty||1)*2) * mult);
      const energy = 1 + Math.ceil((q.difficulty||1)/2);
      $('answerFeedback').innerHTML = `<strong>✓ CORRECT — COMBO ${state.study.combo}</strong>${escapeHtml(q.explanation)}`;
      addRewards({exp,gold,energy});
    } else {
      state.study.combo = 0;
      if (!state.study.reviewIds.includes(q.id)) state.study.reviewIds.push(q.id);
      $('answerFeedback').innerHTML = `<strong>✕ WRONG — 復習問題に追加</strong>${escapeHtml(q.explanation)}`;
      toast('<b>REVIEW ADDED</b> 間違えた問題を復習リストへ登録');
      saveState();
      renderAll();
    }
    $('answerFeedback').classList.add('show');
    $('nextQuestionBtn').classList.remove('hidden');
  }

  function setStudyMode(mode) {
    state.study.mode = mode;
    $$('.seg').forEach(btn => btn.classList.toggle('active', btn.dataset.studyMode === mode));
    $('studyModeHelp').textContent = mode === 'review'
      ? (state.study.reviewIds.length ? `復習待ち ${state.study.reviewIds.length}問から出題します。` : '復習待ちがないため通常問題から出題します。')
      : '全問題から出題します。';
    saveState();
    nextStudyQuestion();
  }

  function enemyForIndex(index) {
    const base = ENEMIES[index % ENEMIES.length];
    const cycle = Math.floor(index / ENEMIES.length);
    const scale = 1 + cycle * .22;
    return {
      ...base,
      level: 1 + index,
      maxHp: Math.round(base.hp * scale),
      hp: Math.round(base.hp * scale),
      atkScaled: Math.round(base.atk * (1 + cycle*.16)),
      expScaled: Math.round(base.exp * (1 + cycle*.18)),
      goldScaled: Math.round(base.gold * (1 + cycle*.18))
    };
  }

  function ensureEnemy(forceNew = false) {
    if (!currentEnemy || forceNew) currentEnemy = enemyForIndex(state.battle.enemyIndex);
    state.battle.playerHp = Math.max(1, Math.min(state.battle.playerHp || state.player.maxHp, state.player.maxHp));
    guardActive = false;
    $('battleActions').classList.remove('hidden');
    $('battleQuiz').classList.add('hidden');
    $('battleResult').classList.add('hidden');
    $('enemyName').textContent = currentEnemy.name;
    $('enemyTier').textContent = currentEnemy.tier;
    $('enemyLevel').textContent = `Lv.${currentEnemy.level}`;
    $('battleLog').textContent = `${currentEnemy.name} が出現。QUIZ STRIKEで知識を攻撃力へ変換せよ。`;
    renderBattleBars();
  }

  function renderBattleBars() {
    if (!currentEnemy) return;
    $('enemyHpText').textContent = `${Math.max(0,currentEnemy.hp)} / ${currentEnemy.maxHp}`;
    $('enemyHpBar').style.width = `${Math.max(0, currentEnemy.hp / currentEnemy.maxHp * 100)}%`;
    $('playerHpText').textContent = `${Math.max(0,state.battle.playerHp)} / ${state.player.maxHp}`;
    $('playerHpBar').style.width = `${Math.max(0, state.battle.playerHp / state.player.maxHp * 100)}%`;
  }

  function startQuizStrike() {
    if (!currentEnemy || currentEnemy.hp <= 0 || state.battle.playerHp <= 0) return;
    battleAnswered = false;
    currentBattleQuestion = pickQuestion('normal', currentBattleQuestion?.id);
    $('battleActions').classList.add('hidden');
    $('battleQuiz').classList.remove('hidden');
    $('battleQuestionSubject').textContent = currentBattleQuestion.subject || 'GENERAL';
    $('battleQuestionText').textContent = currentBattleQuestion.question;
    renderChoices($('battleChoiceGrid'), currentBattleQuestion, (index, btns) => answerBattle(index, btns));
  }

  function answerBattle(index, buttons) {
    if (battleAnswered) return;
    battleAnswered = true;
    const q = currentBattleQuestion;
    const correct = index === q.correct;
    buttons.forEach((btn, i) => {
      btn.disabled = true;
      if (i === q.correct) btn.classList.add('correct');
      if (i === index && !correct) btn.classList.add('wrong');
    });
    state.study.totalAnswered++;
    state.today.answered++;
    state.study.history[q.id] = {answered:(state.study.history[q.id]?.answered || 0)+1, correct:(state.study.history[q.id]?.correct || 0)+(correct?1:0), lastCorrect:correct};

    setTimeout(() => {
      $('battleQuiz').classList.add('hidden');
      if (correct) {
        state.study.totalCorrect++;
        state.today.correct++;
        state.study.combo++;
        state.study.bestCombo = Math.max(state.study.bestCombo, state.study.combo);
        state.study.reviewIds = state.study.reviewIds.filter(id => id !== q.id);
        let damage = Math.round(state.player.atk * (1 + state.study.combo * .018) + (q.difficulty||1)*2);
        const crit = Math.random() < state.player.critical;
        if (crit) damage = Math.round(damage * 1.7);
        currentEnemy.hp -= damage;
        floatDamage(damage, crit);
        $('battleLog').textContent = crit ? `CRITICAL! 正解の知識が ${damage} ダメージを与えた。` : `正解！ ${damage} ダメージ。COMBO ${state.study.combo}`;
        addRewards({exp:4+(q.difficulty||1)*2,gold:2,energy:1}, false);
        if (currentEnemy.hp <= 0) return winBattle();
      } else {
        state.study.combo = 0;
        if (!state.study.reviewIds.includes(q.id)) state.study.reviewIds.push(q.id);
        $('battleLog').textContent = `不正解。${currentEnemy.name} の反撃！`;
        enemyAttack();
        if (state.battle.playerHp <= 0) return loseBattle();
      }
      saveState();
      renderAll();
      setTimeout(() => $('battleActions').classList.remove('hidden'), 220);
    }, 520);
  }

  function enemyAttack() {
    const raw = Math.max(1, currentEnemy.atkScaled - Math.round(state.player.def * .45));
    const damage = guardActive ? Math.max(1, Math.round(raw * .38)) : raw;
    state.battle.playerHp -= damage;
    guardActive = false;
    $('battleStage').classList.remove('shake');
    void $('battleStage').offsetWidth;
    $('battleStage').classList.add('shake');
    floatDamage(damage, false, true);
    renderBattleBars();
  }

  function guard() {
    if (!currentEnemy || currentEnemy.hp <= 0 || state.battle.playerHp <= 0) return;
    guardActive = true;
    const heal = Math.max(3, Math.round(state.player.maxHp * .06));
    state.battle.playerHp = Math.min(state.player.maxHp, state.battle.playerHp + heal);
    $('battleLog').textContent = `GUARD：HPを ${heal} 回復。次の攻撃ダメージを大幅軽減。`;
    renderBattleBars();
    setTimeout(() => {
      enemyAttack();
      if (state.battle.playerHp <= 0) loseBattle();
      else $('battleLog').textContent += ` ${currentEnemy.name} の攻撃を受け流した。`;
      saveState();
      renderAll();
    }, 280);
  }

  function floatDamage(value, crit = false, enemyDmg = false) {
    const el = document.createElement('div');
    el.className = `damage-float${crit?' crit':''}${enemyDmg?' enemy-dmg':''}`;
    el.textContent = enemyDmg ? `-${value}` : `${crit?'CRIT ':''}-${value}`;
    $('floatingLayer').appendChild(el);
    setTimeout(() => el.remove(), 900);
  }

  function winBattle() {
    currentEnemy.hp = 0;
    const exp = currentEnemy.expScaled;
    const gold = currentEnemy.goldScaled;
    const energy = currentEnemy.tier.includes('BOSS') ? 5 : currentEnemy.tier === 'ELITE' ? 3 : 2;
    state.battle.wins++;
    state.battle.enemyIndex++;
    state.battle.playerHp = Math.min(state.player.maxHp, state.battle.playerHp + Math.round(state.player.maxHp*.18));
    $('battleActions').classList.add('hidden');
    $('battleQuiz').classList.add('hidden');
    $('battleResult').classList.remove('hidden');
    $('battleResultTitle').textContent = 'VICTORY';
    $('battleResultText').textContent = `${currentEnemy.name} 撃破 — +${exp} EXP / +${gold} G / +${energy} FE`;
    addRewards({exp,gold,energy}, false);
    toast(`<b>VICTORY</b> ${currentEnemy.name} を撃破`);
    renderBattleBars();
  }

  function loseBattle() {
    state.battle.playerHp = 0;
    $('battleActions').classList.add('hidden');
    $('battleQuiz').classList.add('hidden');
    $('battleResult').classList.remove('hidden');
    $('battleResultTitle').textContent = 'DEFEAT';
    $('battleResultText').textContent = '敗北。ペナルティはありません。HPを全回復して同じ敵へ再挑戦できます。';
    $('nextBattleBtn').textContent = 'RETRY';
    saveState();
    renderAll();
  }

  function nextBattle() {
    const defeated = currentEnemy && currentEnemy.hp <= 0;
    if (defeated) {
      currentEnemy = null;
      $('nextBattleBtn').textContent = 'NEXT ENEMY';
      ensureEnemy(true);
    } else {
      state.battle.playerHp = state.player.maxHp;
      $('nextBattleBtn').textContent = 'NEXT ENEMY';
      ensureEnemy(false);
    }
    saveState();
    renderAll();
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  }

  function bindEvents() {
    $$('[data-nav]').forEach(btn => btn.addEventListener('click', () => navigate(btn.dataset.nav)));
    $('nextQuestionBtn').addEventListener('click', nextStudyQuestion);
    $$('.seg').forEach(btn => btn.addEventListener('click', () => setStudyMode(btn.dataset.studyMode)));
    $('subjectFilter').addEventListener('change', e => setQuestionFilter('subject', e.target.value));
    $('difficultyFilter').addEventListener('change', e => setQuestionFilter('difficulty', e.target.value));
    $('reviewStartBtn').addEventListener('click', () => { setStudyMode('review'); navigate('study'); });
    $('quizStrikeBtn').addEventListener('click', startQuizStrike);
    $('guardBtn').addEventListener('click', guard);
    $('nextBattleBtn').addEventListener('click', nextBattle);
    $('closeLevelModal').addEventListener('click', () => $('levelUpModal').classList.add('hidden'));
  }

  async function init() {
    bindEvents();
    await loadQuestions();
    normalizeFilters();
    buildQuestionFilters();
    $$('.seg').forEach(btn => btn.classList.toggle('active', btn.dataset.studyMode === state.study.mode));
    $('studyModeHelp').textContent = state.study.mode === 'review'
      ? (state.study.reviewIds.length ? `復習待ち ${state.study.reviewIds.length}問から出題します。` : '復習待ちがないため通常問題から出題します。')
      : '全問題から出題します。';
    nextStudyQuestion();
    renderAll();
    saveState();
  }

  init();
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('./sw.js').catch(err => console.info('Service worker registration skipped:', err));
  }
})();
