# STUDY FORGE — PHASE 1 Browser Edition

完全新規で作成した、ブラウザで遊べる STUDY FORGE PHASE 1 です。

## 実装済み
- HOME / PLAYER STATUS
- STUDY（4択問題・解説・報酬）
- 320問の初期問題バンク
- 科目 / 難易度フィルター
- COMBO / EXP / Gold / FORGE ENERGY
- 間違い問題のREVIEW登録
- LEVEL UP / ステータス成長
- QUIZ STRIKEを使う基本戦闘
- localStorage 自動保存 / 自動ロード
- iPhone / iPad / PC レスポンシブ
- PWA manifest / Service Worker（HTTPS配信時）
- GitHub Pagesでそのまま配信可能

## 起動方法
### 1. 一番簡単
`STUDY_FORGE_BROWSER.html` をブラウザで開くと、1ファイルだけで動作します。

### 2. GitHub Pages / Webサーバー
このフォルダ一式を公開してください。`index.html` が入口です。

## 問題データ
- `data/questions.json` : 編集用JSON
- `data/questions.js` : index.htmlをローカル直開きしても動くブラウザ用データ

1問の構造:
```json
{
  "id": "unique-id",
  "question": "問題文",
  "choices": ["A", "B", "C", "D"],
  "correct": 0,
  "explanation": "解説",
  "subject": "運動生理",
  "year": "基礎",
  "difficulty": 1
}
```
`correct` は0始まりです（0=A、1=B、2=C、3=D）。difficultyは1=EASY、2=NORMAL、3=HARD。

## 大量問題追加について
数千問規模でも同じ配列形式で追加できます。将来さらに巨大化する場合は、科目別ファイルへの分割ロードへ移行できるよう、問題データとゲームロジックを分離しています。

## ファイル構成
- `index.html`
- `style.css`
- `script.js`
- `manifest.webmanifest`
- `sw.js`
- `data/questions.json`
- `data/questions.js`
- `assets/icon.svg`
- `assets/weapons/`

PHASE 2ではFORGE / WEAPON / EQUIPMENT / RARITYを追加する想定です。
